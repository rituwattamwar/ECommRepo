﻿using ECommerceViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceBAL
{
   public interface ICartBL
    {
        Task<ProductViewModel> InsertIntoCart(long id,string customerID);
        Task<IEnumerable<CartViewModel>> GetCartDetailsByCustomerIdAsync(string CustomerId);
        Task DeleteCartById(long id);
        Task DeleteCart(string CustomerId);
    }
}
