﻿using ECommerceDAL.Repositories;
using ECommerceViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
namespace ECommerceBAL
{
   public class OrderBL:IOrderBL
    {
       
        
        private IProductRepository objProductRepository;
        private IOrderRepository objOrderRepository;

        public OrderBL(IProductRepository productRepository, IOrderRepository orderRepository)
        {
            objProductRepository = productRepository;

            objOrderRepository = orderRepository;
        }



        public async Task<IEnumerable<OrderViewModel>> GetOrderDetailsAsync(string id)
       {
            
            var OrderList = await objOrderRepository.GetOrderDetailsAsync(id);
            var products = await objProductRepository.GetProductDetailsAsync();

            List<OrderViewModel> OrdersVM = OrderList.Select(x => new OrderViewModel
            {
                OrderId = x.OrderId,
                ProductId = x.ProductId,
                DeliveryAddress = x.DeliveryAddress,
                DeliveryDate = x.DeliveryDate,
                OrderDate = x.OrderDate,
                OrderQuantity = x.OrderQuantity,
                PaymentMethod = x.PaymentMethod,
                CustomerId = x.CustomerId,
                OrderTotal = x.OrderTotal,
                Product = products.Select(y => new ProductViewModel
                {
                    ProductId = y.ProductId,
                    ProductImageUrl = y.ProductImageUrl,
                    ProductName = y.ProductName,
                    ProductPrice = y.ProductPrice,


                }).Where(y => y.ProductId == x.ProductId).FirstOrDefault()


            }).ToList();

            return OrdersVM;
        }


    }
}
