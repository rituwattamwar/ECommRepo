﻿using System;
using System.Collections.Generic;

namespace ECommerceDAL.Models
{
    public partial class Products
    {
        public Products()
        {
            Cart = new HashSet<Cart>();
            Order = new HashSet<Order>();
        }

        public long ProductId { get; set; }
        public long? CategoryId { get; set; }
        public string ProductName { get; set; }
        public string LongDescription { get; set; }
        public string ShortDescription { get; set; }
        public decimal? ProductPrice { get; set; }
        public string ProductImageUrl { get; set; }
        public string ProductImageThumbUrl { get; set; }
        public bool? InStock { get; set; }
        public long? CreatedById { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsActive { get; set; }

        public Category Category { get; set; }
        public ICollection<Cart> Cart { get; set; }
        public ICollection<Order> Order { get; set; }
    }
}
