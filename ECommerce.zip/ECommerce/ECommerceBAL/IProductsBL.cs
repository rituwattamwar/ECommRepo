﻿using ECommerceViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceBAL
{
    public interface IProductsBL
    {
        Task<IEnumerable<ProductViewModel>> GetProductDetailsAsync(string searchText);
        Task<ProductViewModel> GetProductDetailsById(long? id);
        Task<IEnumerable<ProductViewModel>> GetProductDetailsByCategoryIdAsync(long? id);
    }
}
