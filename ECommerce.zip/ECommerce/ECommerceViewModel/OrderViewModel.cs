﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECommerceViewModel
{
    public class OrderViewModel
    {
        public long OrderId { get; set; }
        public long? ProductId { get; set; }
        public string CustomerId { get; set; }


        public decimal? OrderTotal { get; set; }
        public string DeliveryAddress { get; set; }
        public DateTime? OrderDate { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public long? OrderQuantity { get; set; }
        public string PaymentMethod { get; set; }

        public ProductViewModel Product { get; set; }
        public List<OrderViewModel> Orders { get; set; }
    }
}
