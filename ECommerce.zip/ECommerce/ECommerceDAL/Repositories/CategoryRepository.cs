﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ECommerceDAL.Models;
using Microsoft.EntityFrameworkCore;


namespace ECommerceDAL.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {

        private readonly EcomDBContext _context;

        public CategoryRepository()
        {

        }

        public CategoryRepository(EcomDBContext context)
        {
            _context = context;
        }

        //To retrieve category records in Category Table
        public async Task<IEnumerable<Category>> GetCategoryDetailsAsync()
        {
            IEnumerable<Category> objCategory;
            var ecomDBContext = _context.Category;
            try
            {              

                objCategory = await ecomDBContext.ToListAsync();  // using Microsoft.EntityFrameworkCore reference needed for this operation

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }
            return objCategory;
        }
    }
}
