﻿using System;
using System.Collections.Generic;
using System.Text;


namespace ECommerceViewModel
{
    public class CategoryViewModel
    {
        public CategoryViewModel()
        {
            Products = new HashSet<ProductViewModel>();
        }

        public long CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string CategoryImageName { get; set; }
        //   public IEnumerable<Category> Category { get; set; }

        public ICollection<ProductViewModel> Products { get; set; }

       

    }
}
