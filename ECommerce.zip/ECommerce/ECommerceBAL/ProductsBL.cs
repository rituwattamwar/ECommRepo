﻿using ECommerceDAL.Repositories;
using ECommerceViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using ECommerceCommon;



namespace ECommerceBAL
{
    public class ProductsBL:IProductsBL
    {
        private IProductRepository objProductRepository;
       
        private AzureSearchHelper objAzureHelper;

        public ProductsBL(IProductRepository productRepository)
        {
            objProductRepository = productRepository;
           
           
            objAzureHelper = new AzureSearchHelper();

        }




        public async Task<IEnumerable<ProductViewModel>> GetProductDetailsAsync(string searchText)
        {
            if (searchText != "" && searchText != null)
            {

                var products = objAzureHelper.SearchData(searchText);

                List<ProductViewModel> productVM = products.Select(x => new ProductViewModel
                {
                    ProductId = x.ProductId,
                    ProductImageUrl = x.ProductImageUrl,
                    ProductName = x.ProductName,
                    ProductPrice = x.ProductPrice,
                    ShortDescription = x.ShortDescription,
                    CategoryId = x.CategoryId

                }).ToList();
                return productVM;
            }
            else
            {
                var products = await objProductRepository.GetProductDetailsAsync();

                List<ProductViewModel> productVM = products.Select(x => new ProductViewModel
                {
                    ProductId = x.ProductId,
                    ProductImageUrl = x.ProductImageUrl,
                    ProductName = x.ProductName,
                    ProductPrice = x.ProductPrice,
                    ShortDescription = x.ShortDescription,
                    CategoryId = x.CategoryId

                }).ToList();

                return productVM;

            }
        }

        public async Task<IEnumerable<ProductViewModel>> GetProductDetailsByCategoryIdAsync(long? id)
        {
            var Products = await objProductRepository.GetProductDetailsByCategoryIdAsync(id);

            List<ProductViewModel> productVM = Products.Select(x => new ProductViewModel
            {
                ProductId = x.ProductId,
                ProductImageUrl = x.ProductImageUrl,
                ProductName = x.ProductName,
                ProductPrice = x.ProductPrice,
                ShortDescription = x.ShortDescription,
                LongDescription = x.LongDescription,
                CategoryId = x.CategoryId

            }).ToList();

            return productVM;
        }

        public async Task<ProductViewModel> GetProductDetailsById(long? id)
        {
            var products = await objProductRepository.GetProductDetailsAsync();

            ProductViewModel product = products.Select(x => new ProductViewModel
            {
                ProductId = x.ProductId,
                ProductImageUrl = x.ProductImageUrl,
                ProductName = x.ProductName,
                ProductPrice = x.ProductPrice,
                ShortDescription = x.ShortDescription,
                LongDescription = x.LongDescription,
                CategoryId = x.CategoryId
            }).Where(x => x.ProductId == id).FirstOrDefault();
            return product;
        }


        

    }
}
