﻿using ECommerceDAL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
namespace ECommerceDAL.Repositories
{
   public interface IProductRepository
    {
        //  public async System.Threading.Tasks.Task<IEnumerable<Products>> GetProductDetailsAsync();
        Task<IEnumerable<Products>> GetProductDetailsAsync();
        Task<Products> GetProductDetailsById(long? id);
        Task<IEnumerable<Products>> GetProductDetailsByCategoryIdAsync(long? id);

    }
}
