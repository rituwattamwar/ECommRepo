﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceCommon
{
   public interface IRedisFactory
    {
       Task SetValueToRedis(string key, string value, DistributedCacheEntryOptions options);
        Task<string> GetValuefromRedis(string key);
    }
}
