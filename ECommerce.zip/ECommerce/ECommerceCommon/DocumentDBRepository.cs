﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Linq.Expressions;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using ECommerceViewModel;

namespace ECommerceCommon
{
    public class DocumentDBRepository<T> : IDocumentDBRepository<T> where T : class
    {

        private readonly string Endpoint = "https://trainee-ecom-app-cosmosdb.documents.azure.com:443/";
        private readonly string Key = "BFO9FZQTvvSQl9v1pdtFkVoVF29Cl157xJBix5sEsIu0T5ldAoyaU5WyIaa5AqvKAxfTPGMDTjBDZMEUdn4kxQ==";
        private readonly string DatabaseId = "ToDoList";
        private readonly string CollectionId = "Items";
        private DocumentClient client;

        public DocumentDBRepository()
        {
            this.client = new DocumentClient(new Uri(Endpoint), Key);
            //EnableCrossPartitionQuery 
            CreateDatabaseIfNotExistsAsync().Wait();
            CreateCollectionIfNotExistsAsync().Wait();
        }


        //edit
        public async Task<T> GetItemAsync(string id)
        {
            try
            {
                Document document = await client.ReadDocumentAsync(UriFactory.CreateDocumentUri(DatabaseId, CollectionId, id));
                return (T)(dynamic)document;
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }
        }

        //List
        public async Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate)
        {

            //IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
            //    UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId),
            //    new FeedOptions { MaxItemCount = -1, EnableCrossPartitionQuery = true })
            //    .Where(predicate)
            //    .AsDocumentQuery();



            //List<T> results = new List<T>();
            //while (query.HasMoreResults)
            //{
            //    results.AddRange(await query.ExecuteNextAsync<T>());
            //}


            IDocumentQuery<Item> query = client.CreateDocumentQuery<Item>(
                UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId),

                new FeedOptions { MaxItemCount = -1, EnableCrossPartitionQuery = true })
                .Where(p => p.IsActive == true)
                .OrderByDescending<Item, long>(x => x.ClickCount)
                .AsDocumentQuery();



            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                results.AddRange(await query.ExecuteNextAsync<T>());
            }





            //var response = client.CreateDocumentQuery(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId),
            //            "select c.Id,c.ProductId,c.Category,c.ClickCount,c.IsActive from c order by c.ClickCount desc").ToList();
            ////List<T> results = new List<T>();
            ////foreach (var  item in response.ToList())
            ////{
            ////    results.Add(item);
            ////}

            return results;
        }

        public async Task<Document> CreateItemAsync(T item)
        {
            return await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId), item);
        }

        public async Task<Document> UpdateItemAsync(string id, T item)
        {
            return await client.ReplaceDocumentAsync(UriFactory.CreateDocumentUri(DatabaseId, CollectionId, id), item);
        }

        public async Task DeleteItemAsync(string id)
        {
            await client.DeleteDocumentAsync(UriFactory.CreateDocumentUri(DatabaseId, CollectionId, id));
        }

        private async Task CreateDatabaseIfNotExistsAsync()
        {
            try
            {
                await client.ReadDatabaseAsync(UriFactory.CreateDatabaseUri(DatabaseId));
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    await client.CreateDatabaseAsync(new Database { Id = DatabaseId });
                }
                else
                {
                    throw;
                }
            }
        }

        private async Task CreateCollectionIfNotExistsAsync()
        {
            try
            {
                await client.ReadDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId));
            }
            catch (DocumentClientException e)
            {
                if (e.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    await client.CreateDocumentCollectionAsync(
                        UriFactory.CreateDatabaseUri(DatabaseId),
                        new DocumentCollection { Id = CollectionId },
                        new RequestOptions { OfferThroughput = 1000 });
                }
                else
                {
                    throw;
                }
            }
        }

    }

}
