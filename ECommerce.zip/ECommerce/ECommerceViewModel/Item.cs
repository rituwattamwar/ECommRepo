﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Linq;
using System.Threading.Tasks;

using Microsoft.Azure.Documents;
using Newtonsoft.Json;

namespace ECommerceViewModel
{
    public class Item
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "ProductId")]
        public long ProductId { get; set; }

        //[JsonProperty(PropertyName = "Category")]
        //public string Category { get; set; }


        [JsonProperty(PropertyName = "ClickCount")]
        public long ClickCount { get; set; }

        [JsonProperty(PropertyName = "IsActive")]
        public bool IsActive { get; set; }
    }
}
