﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ECommerceDAL.Repositories;
using ECommerceViewModel;
using System.Linq;

namespace ECommerceBAL
{
    public class CartBL : ICartBL
    {
        private ICartRepository objCartRepository;
        private IProductRepository objProductRepository;

        public CartBL(IProductRepository productRepository, ICartRepository cartRepository)
        {
            objProductRepository = productRepository;

            objCartRepository = cartRepository;
        }

        public async Task DeleteCartById(long id)
        {
            await objCartRepository.DeleteCartById(id);
        }
        public async Task DeleteCart(String CustomerId)
        {
            await objCartRepository.DeleteCart(CustomerId);
        }

        public async Task<IEnumerable<CartViewModel>> GetCartDetailsByCustomerIdAsync(string CustomerId)
        {
           // CustomerId = "de9e5e29-0922-4804-9c86-b40813095f9a";

            var products = await objProductRepository.GetProductDetailsAsync();

            var cartList = await objCartRepository.GetCartDetailsByCustomerIdAsync(CustomerId);
            //// ProductViewModel product;
            List<CartViewModel> CartVM = null;


            CartVM = cartList.Select(x => new CartViewModel
            {
                CartId = x.CartId,
                ProductId = x.ProductId,
                ProductQuantity = x.ProductQuantity,
                CustomerId = x.CustomerId,
                Product = products.Select(y => new ProductViewModel
                {
                    ProductId = y.ProductId,
                    ProductImageUrl = y.ProductImageUrl,
                    ProductName = y.ProductName,
                    ProductPrice = y.ProductPrice,


                }).Where(y => y.ProductId == x.ProductId).FirstOrDefault()


            }).ToList();


            return CartVM;
        }

        public async Task<ProductViewModel> InsertIntoCart(long id,string customerID)
        {
            var Cart = await objCartRepository.InsertIntoCart(id,customerID);
            var products = await objProductRepository.GetProductDetailsAsync();

            ProductViewModel ProductVM = products.Select(x => new ProductViewModel
            {
                ProductId = x.ProductId,
                ProductImageUrl = x.ProductImageUrl,
                ProductName = x.ProductName,
                ProductPrice = x.ProductPrice,
                ShortDescription = x.ShortDescription,
                LongDescription = x.LongDescription,
                CategoryId = x.CategoryId
            }).Where(x => x.ProductId == id).FirstOrDefault();

            return ProductVM;

        }






    }
}
