﻿using ECommerceDAL.Models;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using System;
using System.Collections.Generic;
using System.Text;


namespace ECommerceCommon
{
    public class AzureSearchHelper
    {




        private string AzureSearchName { get; set; } //[Your Azure Search Name]"
        private string AzureSearchKey { get; set; }  //"[Your Azure Search Key]"
        private string IndexName { get; set; }   // Index name variable
        public AzureSearchHelper()
        {
            AzureSearchName = "traineeazuresearchforecomapp";
            AzureSearchKey = "6C0AC4CFCF18FAA75A6F7B4D0D9D4585";
            IndexName = "azuresql-index";
        }

        public IEnumerable<Products> SearchData(string STRsearchText)
        {
            // Create a service client connection
            ISearchServiceClient azureSearchService = new SearchServiceClient(AzureSearchName, new SearchCredentials(AzureSearchKey));

            // Get the Azure Search Index
            ISearchIndexClient indexClient = azureSearchService.Indexes.GetClient(IndexName);
            if (azureSearchService.Indexes.Exists(IndexName))
            {
                IEnumerable<Products> productList;
                return productList = Search(indexClient, searchText: STRsearchText);
            }


            return null;
        }

        private IEnumerable<Products> Search(ISearchIndexClient indexClient, string searchText, string filter = null, List<string> order = null, List<string> facets = null)
        {
            List<Products> productsList = new List<Products>();
            // Execute search based on search text and optional filter
            var sp = new SearchParameters();

            // Add Filter
            if (!String.IsNullOrEmpty(filter))
            {
                sp.Filter = filter;
            }

            // Order
            if (order != null && order.Count > 0)
            {
                sp.OrderBy = order;
            }

            // facets
            if (facets != null && facets.Count > 0)
            {
                sp.Facets = facets;
            }

            // Search
            DocumentSearchResult<Products> response = indexClient.Documents.Search<Products>(searchText, sp);


            if (response != null)
            {
                foreach (SearchResult<Products> result in response.Results)
                {
                    productsList.Add(result.Document);
                }


                if (response.Facets != null)
                {
                    foreach (var facet in response.Facets)
                    {
                        Console.WriteLine("\n Facet Name: " + facet.Key);
                        foreach (var value in facet.Value)
                        {
                            Console.WriteLine("Value :" + value.Value + " - Count: " + value.Count);
                        }
                    }
                }



                return productsList;
            }
            else
            {
                return null;
            }







        }





    }
}
