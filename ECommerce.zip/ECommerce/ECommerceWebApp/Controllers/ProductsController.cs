﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ECommerceBAL;
using ECommerceCommon;
using ECommerceViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;

namespace ECommerceWebApp.Controllers
{
    public class ProductsController : Controller
    {
        public IProductsBL _productsBL;
        private IRedisFactory _redisFactory;
        private readonly IDocumentDBRepository<Item> _DocDbRespository;

        public ProductsController(IProductsBL productsBL, IRedisFactory redisFactory, IDocumentDBRepository<Item> objDBRepository)
        {
            _productsBL = productsBL;
            _redisFactory = redisFactory;
            _DocDbRespository = objDBRepository;

        }

        public async Task<IActionResult> Index(string searchText)
        {
            var items = await _DocDbRespository.GetItemsAsync(d => d.IsActive);

            if (string.IsNullOrEmpty(await _redisFactory.GetValuefromRedis("cachedprodlist")))
            {
                IEnumerable<ProductViewModel> productList = await _productsBL.GetProductDetailsAsync(searchText);

                var options = new DistributedCacheEntryOptions();
                options.SetAbsoluteExpiration(new System.TimeSpan(0, 0,15));

              await  _redisFactory.SetValueToRedis("cachedprodlist", JsonConvert.SerializeObject(productList),options);
                return View(productList);
            }

            else {

                var prodlistFromCache = JsonConvert.DeserializeObject<List<ProductViewModel>>(await _redisFactory.GetValuefromRedis("cachedprodlist"));



                return View(prodlistFromCache);


            }
            
        }

        public async Task<IActionResult> Details(long? id)
          {

            ProductViewModel product = await _productsBL.GetProductDetailsById(id);
           // Data.ProductId = product.ProductId;
           
            await ProductDetailsTelemetry(product);

            return View(product);

        }

        public async Task<IActionResult> searchProducts(string searchText)
        {
            IEnumerable<ProductViewModel> productList = await _productsBL.GetProductDetailsAsync(searchText);
            return View(productList);
        }

        public async Task<IActionResult> ProductsFromCategory(long? id)
        {
            IEnumerable<ProductViewModel> prodcutFromCategory = await _productsBL.GetProductDetailsByCategoryIdAsync(id);
            return View(prodcutFromCategory);
        }





        public async Task<string> ProductDetailsTelemetry(ProductViewModel product)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:7071/api/UserVisit");
            await client.PostAsJsonAsync("http://localhost:7071/api/UserVisit/" + product.ProductId, product.ProductId);


            string json = JsonConvert.SerializeObject(product);
            var requestData = new StringContent(json);

            var response = await client.PostAsync(String.Format("http://localhost:7071/api/UserVisit"), requestData);
            var result = await response.Content.ReadAsStringAsync();

            return result;
        }



    }
}