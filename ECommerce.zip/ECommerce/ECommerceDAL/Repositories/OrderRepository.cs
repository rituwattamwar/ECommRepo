﻿using ECommerceDAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceDAL.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly EcomDBContext _context;

        public OrderRepository()
        {

        }

        public OrderRepository(EcomDBContext context)
        {
            _context = context;
        }



        public async Task<IEnumerable<Order>> GetOrderDetailsAsync(string id)
        {

            Guid objOrderNumGenerator = Guid.NewGuid();
            IEnumerable<Order> orders = new List<Order>();


            try
            {

                var cart = await _context.Cart
                    .Include(p => p.Product)
                    .FromSql("select * from Cart where CustomerId={0}", id).ToArrayAsync();


                orders = cart.Select(x => new Order
                {
                    ProductId = x.ProductId,
                    CustomerId = x.CustomerId,
                    Status = "PLACED",
                    OrderNumber = objOrderNumGenerator.ToString(),
                    Product = x.Product,
                    OrderQuantity = x.ProductQuantity,
                    OrderTotal = CalculateOrderTotal(x.ProductId, x.ProductQuantity),
                    DeliveryAddress = "Solapur",
                    OrderDate = DateTime.Now,
                    DeliveryDate = DateTime.Now.AddDays(5),
                    PaymentMethod = "COD",
                    IsActive = true

                }).ToList();

                //var orders = await _context.Order
                // .Include(p => p.Product)
                //.FromSql("select * from Products where CategoryId={0}", id).ToListAsync();

            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }




            return orders;
        }

        public decimal? CalculateOrderTotal(long productId, long productQuantity)
        {
            decimal? productPrice;

            try
            {
                var price = _context.Products
             .Where(x => x.ProductId == productId).FirstOrDefault();
                //.Select(x=>x.ProductPrice);
                //Products product  =  _context.Products

                //   .FromSql("select ProductPrice from Products where ProductId={0}", productId).FirstOrDefault();
                productPrice = price.ProductPrice;

                productPrice = productPrice * productQuantity;


            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }

            return productPrice;
        }



    }
}
