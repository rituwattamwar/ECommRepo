﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.AzureADB2C.UI;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ECommerceCommon;
using Microsoft.EntityFrameworkCore;
using ECommerceDAL.Repositories;
using ECommerceBAL;

namespace ECommerceWebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = new ConfigurationBuilder().SetBasePath(env.ContentRootPath).AddJsonFile("appSettings.json").Build();
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });


            services.AddDistributedRedisCache(options =>
            {

                options.Configuration = Configuration.GetConnectionString("RedisConnection");
                options.InstanceName = "instance";
            });

            services.AddScoped<IRedisFactory, RedisHelper>();
          services.AddDbContext<ECommerceDAL.Models.EcomDBContext>(options => options.UseSqlServer(Configuration.GetConnectionString("EComDBConnectionStr")));

            services.AddAuthentication(AzureADB2CDefaults.AuthenticationScheme)
                .AddAzureADB2C(options => Configuration.Bind("AzureAdB2C", options));

            services.AddScoped<ICategoryBL, CategoryBL>();
            services.AddScoped<ICategoryRepository, CategoryRepository>();

            services.AddScoped<IProductsBL, ProductsBL>();
            services.AddScoped<IProductRepository, ProductRepository>();

            services.AddScoped<IOrderBL, OrderBL>();
            services.AddScoped<IOrderRepository, OrderRepository>();

            services.AddScoped<ICartRepository, CartRepository>();
            services.AddScoped<ICartBL, CartBL>();

            services.AddSingleton<IDocumentDBRepository<ECommerceViewModel.Item>>(new DocumentDBRepository<ECommerceViewModel.Item>());


            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
