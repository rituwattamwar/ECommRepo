﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using ECommerceBAL;
using ECommerceViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceWebApp.Controllers
{
    [Authorize]
    public class OrderController : Controller
    {
        public IOrderBL _orderBL;
        public ICartBL _cartBL;

        public OrderController(IOrderBL orderBL, ICartBL cartBL)
        {
            _orderBL = orderBL;
            _cartBL = cartBL;
        }

        public async Task<IActionResult> PlaceOrder()
        {
            string signedInUserID = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

            IEnumerable<OrderViewModel> orderVM = await _orderBL.GetOrderDetailsAsync(signedInUserID);
            return View(orderVM);
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Thankyou()
        {
            string signedInUserID = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            await _cartBL.DeleteCart(signedInUserID);
            return View();
        }
    }
}