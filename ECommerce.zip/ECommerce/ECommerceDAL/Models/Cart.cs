﻿using System;
using System.Collections.Generic;

namespace ECommerceDAL.Models
{
    public partial class Cart
    {
        public long CartId { get; set; }
        public string CustomerId { get; set; }
        public long ProductId { get; set; }
        public long ProductQuantity { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? CreatedById { get; set; }
        public bool? IsActive { get; set; }

        public Products Product { get; set; }
    }
}
