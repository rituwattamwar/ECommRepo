﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using ECommerceBAL;
using ECommerceViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceWebApp.Controllers
{
    [Authorize]
    public class CartsController : Controller
    {
        public ICartBL _cartBL;
        public IProductsBL _productsBL;

        public CartsController(ICartBL cartBL, IProductsBL productsBL)
        {
            _cartBL = cartBL;
            _productsBL = productsBL;

        }
        public async Task<IActionResult> List()
        {
            string CustomerId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            IEnumerable<CartViewModel> CartVM = await _cartBL.GetCartDetailsByCustomerIdAsync(CustomerId);
            return View(CartVM);
        }

        public async Task<IActionResult> Delete(long id)
        {
            await _cartBL.DeleteCartById(id);
            return RedirectToAction(nameof(List));
        }

        public async Task<IActionResult> AddToCart(long id)
        {
            string CustomerId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;

            ProductViewModel productVM = await _cartBL.InsertIntoCart(id,CustomerId);
            return View(productVM);
        }
    }
}