﻿using System;
using System.Collections.Generic;

namespace ECommerceDAL.Models
{
    public partial class Order
    {
        public long OrderId { get; set; }
        public long? ProductId { get; set; }
        public string CustomerId { get; set; }
        public string Status { get; set; }
        public string OrderNumber { get; set; }
        public decimal? OrderTotal { get; set; }
        public string DeliveryAddress { get; set; }
        public DateTime? OrderDate { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public long? OrderQuantity { get; set; }
        public string PaymentMethod { get; set; }
        public bool? IsActive { get; set; }

        public Products Product { get; set; }
    }
}
