﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceCommon
{
   public class RedisHelper:IRedisFactory
    {

        private IDistributedCache _cache;


        public RedisHelper(IDistributedCache cache)
        {
            _cache = cache;
        }

        //public RedisHelper()
        //{



        //}

        public async Task SetValueToRedis(string key, string value, DistributedCacheEntryOptions options)
        {
          await  _cache.SetStringAsync(key, value, options);
        }

        public async Task<string> GetValuefromRedis(string key)
        {
            return await _cache.GetStringAsync(key);

        }




    }
}
