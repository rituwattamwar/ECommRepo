﻿using ECommerceDAL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceDAL.Repositories
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetOrderDetailsAsync(string id);
        //Task<IEnumerable<Products>> GetProductDetailsByCategoryIdAsync(long? id);

    }
}
