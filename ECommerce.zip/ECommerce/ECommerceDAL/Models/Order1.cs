﻿using System;
using System.Collections.Generic;

namespace ECommerceDAL.Models
{
    public partial class Order1
    {
        public int OrderId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Product { get; set; }
    }
}
