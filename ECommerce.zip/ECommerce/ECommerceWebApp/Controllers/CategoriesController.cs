﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ECommerceBAL;
using ECommerceViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


namespace ECommerceWebApp.Controllers
{
    [Authorize]
    public class CategoriesController : Controller
    {

        private ICategoryBL objCategoryBL;

       
        public CategoriesController(ICategoryBL categoryBL)
        {

            objCategoryBL = categoryBL;
        }
        public async Task<IActionResult> Index()
        {
            IEnumerable<CategoryViewModel> categoryList = await objCategoryBL.GetCategoryDetailsAsync();
            return View(categoryList);


        }
    }
}