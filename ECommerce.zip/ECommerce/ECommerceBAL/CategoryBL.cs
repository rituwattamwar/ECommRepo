﻿using ECommerceDAL.Repositories;
using ECommerceViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ECommerceBAL
{
    public class CategoryBL : ICategoryBL
    {

        private ICategoryRepository objCategoryRepository;
        public CategoryBL()
        {

        }
        public CategoryBL(ICategoryRepository category)
        {
            objCategoryRepository = category;
        }

        public async Task<IEnumerable<CategoryViewModel>> GetCategoryDetailsAsync()
        {

            var categoryData = await objCategoryRepository.GetCategoryDetailsAsync();
            IEnumerable<CategoryViewModel> cartList = categoryData
                .Select(x => new CategoryViewModel
                {
                    CategoryId = x.CategoryId,
                    CategoryName = x.CategoryName,
                    CategoryImageName = x.CategoryImageName
                }).ToList();
            return cartList;

        }

        //Task<IEnumerable<CategoryViewModel>> ICategoryBL.GetCategoryDetailsAsync()
        //{
        //    throw new NotImplementedException();
        //}
    }
}
