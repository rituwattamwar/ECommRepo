﻿using ECommerceDAL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceDAL.Repositories
{
    public interface ICartRepository
    {
        Task<Cart> InsertIntoCart(long id,string customerID);
        Task<IEnumerable<Cart>> GetCartDetailsByCustomerIdAsync(string CustomerId);
        Task DeleteCartById(long id);
        Task DeleteCart(string CustomerId);

    }
}
