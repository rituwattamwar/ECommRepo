﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECommerceViewModel
{
    public class CartViewModel
    {
        public long CartId { get; set; }
        public string CustomerId { get; set; }
        public long ProductId { get; set; }
        public long ProductQuantity { get; set; }

        public ProductViewModel Product { get; set; }
        public IEnumerable<ProductViewModel> Products { get; set; }
    }
}
