﻿using System;
using System.Collections.Generic;
using System.Text;
using ECommerceDAL.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace ECommerceDAL.Repositories
{


    public class ProductRepository : IProductRepository
    {
        private readonly EcomDBContext _context;

        public ProductRepository()
        {

        }

        public ProductRepository(EcomDBContext context)
        {
            _context = context;
        }

        //This method will fetch all product details from Products Table 
        public async System.Threading.Tasks.Task<IEnumerable<Products>> GetProductDetailsAsync()
        {
            var ecomDBContext = _context.Products.Include(p => p.Category);

            IEnumerable<Products> p1 = new List<Products>();
            try
            {
                
                    p1 = await ecomDBContext.ToListAsync();
               

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }
            return p1;


        }

       
        //This method will fetch  product details by ProductId from Products Table 
        public async Task<Products> GetProductDetailsById(long? id)
        {

            try
            {

               var products = await _context.Products
               .Include(p => p.Category)
               .FirstOrDefaultAsync(m => m.ProductId == id);
                return products;

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);

            }



        }


        //This method will fetch  product details by filter with CategoryId from Products Table 
        public async Task<IEnumerable<Products>> GetProductDetailsByCategoryIdAsync(long? id)
        {

            try
            {

            var products = await _context.Products
              .Include(p => p.Category)
              .FromSql("select * from Products where CategoryId={0}",id).ToListAsync();
              
            return products;

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);

            }
        }



    }
}
