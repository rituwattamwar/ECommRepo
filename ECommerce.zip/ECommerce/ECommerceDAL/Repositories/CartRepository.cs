﻿using ECommerceDAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
namespace ECommerceDAL.Repositories
{
    public class CartRepository : ICartRepository
    {
        private readonly EcomDBContext _context;

        public CartRepository()
        {

        }

        public CartRepository(EcomDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Cart>> GetCartDetailsByCustomerIdAsync(string CustomerId)
        {

            var ecomDBContext = _context.Cart;
            try
            {

                var cart = await _context.Cart
            .Include(p => p.Product)
            .FromSql("select * from Cart where CustomerId={0}", CustomerId).ToListAsync();
                return cart;


            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }

        }

        public async Task DeleteCart(string CustomerId)
        {
            var ecomDBContext = _context.Cart;
            try
            {
                _context.Cart.RemoveRange(await _context.Cart
            .FromSql("select * from Cart where CustomerId={0}", CustomerId).ToListAsync() as IEnumerable<Cart>);


                //  _context.Update(cart);
                await _context.SaveChangesAsync();

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }

        }
        public async Task<Cart> InsertIntoCart(long id, string customerID)
        {
            Cart cart = new Cart();

            try
            {
                var CartVM = await GetCartDetailsByCustomerIdAsync(customerID);

                foreach (var item in CartVM)
                {
                    if (item.ProductId == id)
                    {
                        var carts = await _context.Cart.FirstOrDefaultAsync(m => m.ProductId == item.ProductId);


                        carts.ProductQuantity = (item.ProductQuantity)++;
                        carts.ProductId = item.ProductId;
                        carts.CustomerId = item.CustomerId;
                        _context.Update(carts);
                        await _context.SaveChangesAsync();
                        return carts;

                    }
                }


                var product = await _context.Products
                    .Include(p => p.Category)
                    .FirstOrDefaultAsync(m => m.ProductId == id);

                var name = product.ProductName;
                var price = product.ProductPrice;
                cart.ProductQuantity = 1;
                cart.CustomerId = customerID;
                cart.ProductId = id;
                _context.Update(cart);
                await _context.SaveChangesAsync();
                return cart;

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }

        }

        public async Task DeleteCartById(long id)
        {

            try
            {
            var cart = await _context.Cart.
                Include(p => p.Product)
                .FirstOrDefaultAsync(m => m.CartId == id);

            _context.Remove(cart);

            await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }

        }
    }
}
