
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;
using Microsoft.Azure.EventHubs;


using Microsoft.Extensions.Logging;

using System.Text;
using System.Threading.Tasks;

namespace ECommHttpTrigger
{
    public static class UserVisit
    {
        [FunctionName("UserVisit")]
        
        public static async Task Run(
[HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string name = req.Query["name"];

            string requestBody = new StreamReader(req.Body).ReadToEnd();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            //dynamic data = JsonConvert.DeserializeObject(requestBody);

            log.LogInformation("********************************************");
            log.LogInformation(requestBody);
            log.LogInformation("********************************************");
            log.LogInformation("---------------Crteating Event Hub From Namespace ---------------");


            EventHubClient eventHubClient;

            string EventHubConnectionString = "Endpoint=sb://traineeecomeventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=fUW0ezKo9WGTUdSFyYW/Vfe8q7vahMTz0ajAk/Hfhks=";
            string EventHubName = "traineeecomeventhub";
            var connectionStringBuilder = new EventHubsConnectionStringBuilder(EventHubConnectionString)
            {
                EntityPath = EventHubName
            };
            eventHubClient = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
            // var msg = "Hello";
            await eventHubClient.SendAsync(new EventData(Encoding.UTF8.GetBytes(requestBody)));

            log.LogInformation("---------------Connected Successfully ---------------");
            log.LogInformation("---------------Data Sent To Hub ---------------");

        }

    }
    }

