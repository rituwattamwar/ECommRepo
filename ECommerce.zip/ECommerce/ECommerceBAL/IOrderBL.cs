﻿using ECommerceViewModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceBAL
{
   public interface IOrderBL
    {

    Task<IEnumerable<OrderViewModel>> GetOrderDetailsAsync(string id);
    }
}
